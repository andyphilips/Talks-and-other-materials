#
# Estimating ARIMA models
# 9/26/19
# Andrew Q. Philips
# -------------------------------------

# we're going to work with a series of commodity prices (all expressed in US$ per metric ton)
library(readxl)
commodity_prices <- read_excel("commodity-prices.xls")
head(commodity_prices) 


# let's model the banana series:
plot(commodity_prices$date, commodity_prices$bananas, type = 'l', col = 'orange', main = 'Banana Prices')


# next, let's see if it's stationary:
# install.packages("fUnitRoots") 
library(fUnitRoots)
adfTest(commodity_prices$bananas, lags = 0) # can't reject null, so I(1).

# Also a good idea to include lags...helps purge autocorrelation
adfTest(commodity_prices$bananas, lags = 10) # can't reject null, so I(1).

# is the first difference stationary?
adfTest(diff(commodity_prices$bananas), lags = 10) # yes.
# so I = 1
plot(commodity_prices$date[2:length(commodity_prices$date)], diff(commodity_prices$bananas), type = 'l', col = 'orange', main = 'First-difference of Banana Prices')

# now let's estimate an ARIMA(1,1,0)
library(forecast)
arima.110 <- Arima(commodity_prices$bananas, order = c(1,1,0))
print(arima.110)

# we may want a constant:
arima.110 <- Arima(commodity_prices$bananas, order = c(1,1,0), include.constant = TRUE)
print(arima.110)
# how do we know how well it fits?
plot(arima.110$residuals)
acf(arima.110$residuals) # the autocorrelation function correlates e with lags of itself. We want these to be 0. Significant spikes may indicate an AR process
pacf(arima.110$residuals) # partial autocorrelation functions are similar to ACFs (but control for all prior lags). Significant spikes may indicate an AR process

# difference between an MA and an AR process? AR tends to show up as geometric decay in the ACF. MA process tend to appear as a single spike in the ACF, but geometric decay in the PACF

tsdiag(arima.110) # we can get a bunch of into with tsdiag. the Ljung-Box Q is a Portmanteau test, and if we reject the null it means the series is NOT white noise. Looks like there may be something going on at t = 4.

# looks like the may be an AR(4) process. We could estimate an AR 1, 2, 3 ,4 term model, or simply create an AR(1,4) model
arima.110.100 <- Arima(commodity_prices$bananas, order = c(1,1,0), seasonal=list(order=c(1,0,0), period = 4), include.constant = TRUE)
print(arima.110.100)
plot(arima.110.100$residuals)
acf(arima.110.100$residuals) 
pacf(arima.110.100$residuals) 
tsdiag(arima.110.100) 
# now it's looking like there is something going on at lag 12. While we can't add two seasonal components, we might try an ARIMA(4,1,0) with seasonal (1,0,0) at 12 months

arima.410.100 <- Arima(commodity_prices$bananas, order = c(4,1,0), seasonal=list(order=c(1,0,0), period = 12), include.constant = TRUE)
print(arima.410.100)
plot(arima.410.100$residuals)
acf(arima.410.100$residuals) 
pacf(arima.410.100$residuals) 
tsdiag(arima.410.100)

# what I only want a lag at 1 and 4 without the consecutive ones?
arima.new.410.100 <- Arima(commodity_prices$bananas, order = c(4,1,0), seasonal=list(order=c(1,0,0), period = 12), include.constant = TRUE, fixed = c(NA,0,0,NA,NA,NA))
print(arima.new.410.100)
plot(arima.new.410.100$residuals)
acf(arima.new.410.100$residuals) 
pacf(arima.new.410.100$residuals) 
tsdiag(arima.new.410.100)

# using AIC/BIC to find the best model:
# just remember that these need to be estimated on the same data:
arima.new.410.100$nobs
arima.410.100 <- Arima(commodity_prices$bananas, order = c(4,1,0), seasonal=list(order=c(1,0,0), period = 12), include.constant = TRUE)
arima.new.410.100$nobs
arima.111.100 <- Arima(commodity_prices$bananas, order = c(1,1,1), seasonal=list(order=c(1,0,0), period = 12), include.constant = TRUE)
arima.111.100$nobs
# these are all the same b/c of the seasonal lag. You'd have to adjust sample size with commodity_prices$bananas[x:length(commodity_prices$bananas)] if not
AIC(arima.new.410.100, arima.410.100, arima.111.100) # arima.111.100 looks to be the best


# we can also cheat and have R automatically select:
auto.arima(commodity_prices$bananas, seasonal=FALSE)
# by default it maxes out at p,d,q = 5
auto.arima(commodity_prices$bananas, seasonal=TRUE, max.d = 1, max.p = 12, max.q = 12)

# does this fit better than what we found above?
arima.412 <- Arima(commodity_prices$bananas, order = c(4,1,2), include.constant = TRUE)
arima.412$nobs
AIC(arima.412) # yes

