#
# Forecasting ARIMA models
# 9/26/19
# Andrew Q. Philips
# -------------------------------------

# we're going to work with a series of commodity prices (all expressed in US$ per metric ton)
library(readxl)
commodity_prices <- read_excel("commodity-prices.xls")
head(commodity_prices) 


# let's model the banana series:
plot(commodity_prices$date, commodity_prices$bananas, type = 'l', col = 'orange', main = 'Banana Prices')

# previously we saw that this was the best-fitting model:
library(forecast)
arima.412 <- Arima(commodity_prices$bananas, order = c(4,1,2), include.constant = TRUE)
print(arima.412)

# forecasting: for comparison out of sample, we'll refit our model on all but the last 30 observations:
arima.412 <- Arima(commodity_prices$bananas[1:(length(commodity_prices$bananas) - 30)], order = c(4,1,2), include.constant = TRUE)
print(arima.412)

# we can use the forecast function to predict however many steps ahead:
f.casts <- forecast(arima.412, h = 30, level = c(95))
plot(f.casts)
plot(f.casts)
lines(commodity_prices$bananas, col = 'red') # compare how we did with actual

# how does this compare to say a naiive model of ARIMA(0,1,0)?
arima.naiive <- Arima(commodity_prices$bananas[1:(length(commodity_prices$bananas) - 30)], order = c(0,1,0), include.constant = TRUE)
print(arima.naiive)
f.casts2 <- forecast(arima.naiive, h = 30, level = c(95))
plot(f.casts2)
lines(commodity_prices$bananas, col = 'red')

# create a RMSE criterion for our two competing models:
sqrt(mean((f.casts$mean - commodity_prices$bananas[327:356])^2))
sqrt(mean((f.casts2$mean - commodity_prices$bananas[327:356])^2))
# so it looks like our naiive model actually performs better!

# note that these are not dynamically updated...new information stops as soon as we reach the end of the sample.

# another type of forecast is one-step:
one.step <- fitted(arima.412)
plot.ts(commodity_prices$bananas[1:(length(commodity_prices$bananas) - 30)], col = 'orange', main = 'Banana Prices (orange) and one-step forecast (black)')
lines(one.step)
# compare to naiive prediction:
one.step2 <- fitted(arima.naiive)
lines(one.step2, lty = 3)


